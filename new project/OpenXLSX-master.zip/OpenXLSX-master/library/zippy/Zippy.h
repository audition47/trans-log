//
// Created by Troldal on 2019-03-13.
//

#ifndef Zippy_Zippy_H
#define Zippy_Zippy_H

#include "Zippy/ZipArchive.h"
#include "Zippy/ZipEntry.h"
#include "Zippy/ZipException.h"

#endif //Zippy_Zippy_H
